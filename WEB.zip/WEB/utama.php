<!DOCTYPE html>
 <html class="no-js">
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>A'Medical Healt Care</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">



	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>


	<link rel="shortcut icon" href="favicon.ico">

	<link rel="stylesheet" href="css/superfish.css">

	<link rel="stylesheet" href="css/bootstrap-datepicker.min.css">

	<link rel="stylesheet" href="css/cs-select.css">
	<link rel="stylesheet" href="css/cs-skin-border.css">


	<link rel="stylesheet" href="css/themify-icons.css">

	<link rel="stylesheet" href="css/flaticon.css">

	<link rel="stylesheet" href="css/icomoon.css">

	<link rel="stylesheet" href="css/flexslider.css">
	

	<link rel="stylesheet" href="css/style.css">

	<script src="js/modernizr-2.6.2.min.js"></script>

</head>
<body>
	<div id="fh5co-wrapper">
	<div id="fh5co-page">
	<div id="fh5co-header">
		<header id="fh5co-header-section">
			<div class="container">
				<div class="nav-header">
					<a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle"><i></i></a>
					<h1 id="fh5co-logo"><a href="index.html">A'Medical Healt Care</a></h1>
					<nav id="fh5co-menu-wrap" role="navigation">
						<ul class="sf-menu" id="fh5co-primary-menu">
							<li><a class="active" href="utama.php">BERANDA</a></li>
							<li>
							<li><a href="php-crud-master/index.php">IDENTITAS</a></li>
							<li>
							<li><a href="index.php">LOG OUT </a></li>
						</ul>
					</nav>
				</div>
			</div>
		</header>
		
	</div>
	<aside id="fh5co-hero" class="js-fullheight">
		<div class="flexslider js-fullheight">
			<ul class="slides" style="width: 1355px;">
		   	<li style="background-image: url(images/slider1.jpg);">
		   		<div class="overlay-gradient"></div>
		   		<div class="container">
		   			<div class="col-md-12 col-md-offset-0 text-center slider-text">
		   				<div class="slider-text-inner js-fullheight">
		   					<div class="desc">
		   						<p><span>"PENYAKIT"</span></p>
		   						<h2>MARI BELAJAR TENTANG BEBERAPA PENYAKIT</h2>
			   					<p>
			   						<a href="#" class="btn btn-primary btn-lg">KESEHATAN ITU PENTING</a>
			   					</p>
		   					</div>
		   				</div>
		   			</div>
		   		</div>
		   	</li>
		   	<li style="background-image: url(images/slider2.jpg);">
		   		<div class="overlay-gradient"></div>
		   		<div class="container">
		   			<div class="col-md-12 col-md-offset-0 text-center slider-text">
		   				<div class="slider-text-inner js-fullheight">
		   					<div class="desc">
		   						<p><span>"PENOLONGAN PERTAMA"</span></p>
		   						<h2>LAKUKAN PENOLONGAN PERTAMA JIKA ANDA TERLUKA</h2>
			   					<p>
			   						<a href="#" class="btn btn-primary btn-lg">KESEHATAN ITU PENTING</a>
			   					</p>
		   					</div>
		   				</div>
		   			</div>
		   		</div>
		   	</li>
		   	<li style="background-image: url(images/slider3.jpg);">
		   		<div class="overlay-gradient"></div>
		   		<div class="container">
		   			<div class="col-md-12 col-md-offset-0 text-center slider-text">
		   				<div class="slider-text-inner js-fullheight">
		   					<div class="desc">
		   						<p><span>"FUTURELIFE"</span></p>
		   						<h2>JAGALAH KESEHATANMU TUK MASADEPANMU</h2>
			   					<p>
			   						<a href="#" class="btn btn-primary btn-lg">KESEHATAN ITU PENTING</a>
			   					</p>
		   					</div>
		   				</div>
		   			</div>
		   		</div>
		   	</li>
		   	
		  	</ul>
	  	</div>

	

	<div id="featured-hotel" class="fh5co-bg-color">
		<div class="container">
			
			<div class="row">
				<div class="col-md-12">
					<div class="section-title text-center">
						<h2>"JENIS-JENIS PENYAKIT"</h2>
					</div>
				</div>
			</div>

			<div class="row">
				<div class="feature-full-1col">
					<div class="image" style="background-image: url(images/Kanker.jpg);">
						<div class="descrip text-center">
							<p><small>TINGKATAN</small><span>BEBAHAYA!</span></p>
						</div>
					</div>
					<div class="desc">
						<h3>KANKER</h3>
						<p>Kanker adalah istilah umum untuk pertumbuhan sel tidak normal, yaitu tumbuh sangat cepat, tidak terkontrol, dan tidak berirama, yang dapat menyusup ke jaringan tubuh normal dan menekan jaringan tubuh normal sehingga mempengaruhi fungsi tubuh</p>
						<p><a href="#" class="btn btn-primary btn-luxe-primary">PELAJARI <i class="ti-angle-right"></i></a></p>
					</div>
				</div>

				<div class="feature-full-2col">
					<div class="f-hotel">
						<div class="image" style="background-image: url(images/cacarair.jpg);">
							<div class="descrip text-center">
								<p><small>TINGKATAN</small><span>RENDAH</span></p>
							</div>
						</div>
						<div class="desc">
							<h3>CACAR AIR</h3>
							<p>Cacar air adalah  adalah infeksi virus pada kulit dan membran mukosa, yang menyebabkan lenting pada seluruh tubuh dan wajah. Penyakit cacar air, atau biasa disebut chickenpox (varisela)</p>
							<p><a href="#" class="btn btn-primary btn-luxe-primary">PELAJARI <i class="ti-angle-right"></i></a></p>
						</div>
					</div>
					<div class="f-hotel">
						<div class="image" style="background-image: url(images/asma.jpg);">
							<div class="descrip text-center">
								<p><small>TINGKATAN</small><span>BERBAHAYA</span></p>
							</div>
						</div>
						<div class="desc">
							<h3>ASMA</h3>
							<p>Asma adalah penyakit yang bersifat alergis, artinya penyakit ini akan kambuh jika dipengaruhi oleh sesuatu seperti udara dingin, makanan, obat-obatan, bau menyengat dan lingkungan berdebu. </p>
							<p><a href="#" class="btn btn-primary btn-luxe-primary">PELAJARI <i class="ti-angle-right"></i></a></p>
						</div>
					</div>
				</div>
			</div>

		</div>
	</div>

	<div id="hotel-facilities">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="section-title text-center">
						<h2>TETAP SEHAT DENGAN:</h2>
					</div>
				</div>
			</div>

			<div id="tabs">
				<nav class="tabs-nav">
					<a href="#" class="active" data-tab="tab1">
						<i class="flaticon-restaurant icon"></i>
						<span>MAKAN SAYUR</span>
					</a>
					<a href="#" data-tab="tab2">
						<i class="flaticon-cup icon"></i>
						<span>MINUM AIR PUTIH</span>
					</a>
					<a href="#" data-tab="tab3">
					
						<i class="flaticon-car icon"></i>
						<span>RUTIN CEK KESEHATAN</span>
					</a>
					<a href="#" data-tab="tab4">
						
						<i class="flaticon-swimming icon"></i>
						<span>BEROLAHRAGA</span>
					</a>
					<a href="#" data-tab="tab5">
						
						<i class="flaticon-massage icon"></i>
						<span>KESEHARIAN YANG BAIK</span>
					</a>
					<a href="#" data-tab="tab6">
						
						<i class="flaticon-bicycle icon"></i>
						<span>JAGALAH LINGKUNGAN</span>
					</a>
				</nav>
				<div class="tab-content-container">
					<div class="tab-content active show" data-tab-content="tab1">
						<div class="container">
							<div class="row">
								<div class="col-md-6">
									<img src="images/sayur.jpg" class="img-responsive" alt="Image">
								</div>
								<div class="col-md-6">
									<span class="super-heading-sm">PERTAMA</span>
									<h3 class="heading">MAKAN SAYUR</h3>
									<p>Untuk badan tetap sehat dan segar salah satu caranya adalah dengan makan sayur,Kenapa? karena banyak sayur yang mengandung banyak sekali kandungan yang menyehatkan seperti vitamin DLL yang dapat membuat tubuh kita selalu segar dan sehat, selain itu sayur juga dapat menghindarkan anda dari berbagai penyakit Berbahaya.</p>
									<p>Jadi, apabila anda merasa jarang menkonsumsi sayur-sayuran maka mulai sekarang konsumsilah sayur, karena itu penting untuk kesehatan di masadepan anda</p>
									<p class="service-hour">
										<span>JAGA KESEHATAN</span>
										<strong>"UNTUK MASADEPAN YANG CERAH"</strong>
									</p>
								</div>
							</div>
						</div>
					</div>
					<div class="tab-content" data-tab-content="tab2">
						<div class="container">
							<div class="row">
								<div class="col-md-6">
									<img src="images/airputih.jpg" class="img-responsive" alt="Image">
								</div>
								<div class="col-md-6">
									<span class="super-heading-sm">KEDUA</span>
									<h3 class="heading">MINUM AIR PUTIH</h3>
									<p>Perlu diketahui tubuh kita terdiri lebih dari 70% cairan yang mana kebutuhan akan cairan sangat tinggi.Jadi air dalam tubuh kita tentu tidak dapat digantikan oleh apapun, Air putih alami juga memiliki banyak manfaat, seperti:Menjaga keseimbangan cairan dalam tubuh,membantu mengeluarkan racun,menjaga fungsi ginjal,meningkatkan fungsi otak,meningkatkan energi,Dll .</p>
									<p>Jadi, setelah anda tahu manfaat dari air putih maukah anda untuk rutin meminumnya?,karena dibandingkan dengan meminum minuman yang mengandung pewarna dan pengawet yang tidak sehat Bukankah lebih baik meminum air putih saja. </p>
									<p class="service-hour">
										<span>JAGA KESEHATAN</span>
										<strong>"UNTUK MASADEPAN YANG CERAH"</strong>
									</p>
								</div>
							</div>
						</div>
					</div>
					<div class="tab-content" data-tab-content="tab3">
						<div class="container">
							<div class="row">
								<div class="col-md-6">
									<img src="images/rumahsakit.jpg" class="img-responsive" alt="Image">
								</div>
								<div class="col-md-6">
									<span class="super-heading-sm">KETIGA</span>
									<h3 class="heading">RUTIN CEK KESEHATAN</h3>
									<p>Jika anda sudah berumur cukup tua sekitar 60 ke atas dan mearasakan ada merasa kurang sehat, maka anda harus rutin cek kesehatan ke puskesmas atau rumah sakit karena bisa jadi anda terserang virus/penyakit tetapi anda tidak menyadarinya, selain itu anda juga dapat berkonsultasi dengan dokter disana tentang hidup sehat dan terhindarkan dari penyakit.</p>
									<p>Selain Orang dewasa dan lansia, balita juga disarankan untuk ikut rutin cek kesehatan agar terhindar dari virus dan penyakit, contohnya dengan rutin mengikuti imunisasi bagi balita di puskesmas.</p>
									<p class="service-hour">
										<span>JAGA KESEHATAN</span>
										<strong>"UNTUK MASADEPAN YANG CERAH"</strong>
									</p>
								</div>
							</div>
						</div>
					</div>
					<div class="tab-content" data-tab-content="tab4">
						<div class="container">
							<div class="row">
								<div class="col-md-6">
									<img src="images/olahraga.jpg" class="img-responsive" alt="Image">
								</div>
								<div class="col-md-6">
									<span class="super-heading-sm">KEEMPAT</span>
									<h3 class="heading">BEROLAHRAGA</h3>
									<p>Sebagai sebuah kegiatan yang bisa melemaskan otot-otot tubuh, olahraga dinilai sangat penting bagi semua orang. Tak peduli itu orang dewasa ataupun anak-anak, jika tak pernah berolahraga pasti akan merasakan dampat negatifnya. Olahraga dianjurkan untuk semua orang, baik yang sehat, sedang menjalankan diet, bahkan bagi orang yang kurang sehat pun terkadang disarankan untuk berolahraga karena faktanya olahraga mampu mengembalikan kesehatan tubuh dan mampu membakar lemak jahat yang tertimbun di dalam tubuh.</p>
									<p>Jadi, Berolahragalah setiap hari untuk hidup sehat dan selalu terhindar dari penyakit.</p>
									<p class="service-hour">
										<span>JAGA KESEHATANMU</span>
										<strong>"UNTUK MASADEPAN YANG CERAH"</strong>
									</p>
								</div>
							</div>
						</div>
					</div>
					<div class="tab-content" data-tab-content="tab5">
						<div class="container">
							<div class="row">
								<div class="col-md-6">
									<img src="images/keseharian.jpg" class="img-responsive" alt="Image">
								</div>
								<div class="col-md-6">
									<span class="super-heading-sm">KELIMA</span>
									<h3 class="heading">KESEHARIAN YANG BAIK</h3>
									<p>Untuk menjaga tubuh anda tetap sehat anda perlu kebiasaan yang baik dari diri anda juga, contohnya jika anda ingin bepergian jauh biasanya anda menggunakan tranportasi yang justru akan memkerkeruh udara lingkungan, maka lebih baik berjalan kaki, ketika bangun tidur apakah yang anda lakukan? mencari ponsel anda atau mencari barang yang lain?? itu salah, seharusnya anda berolahraga ringan seperti menggerakan tangan anda dan bangunlah secara perlahan.</p>
									<p>Karena itu semua demi tubuh anda agar tidak merasa berat nantinya pada saat dewasa dan masa Tua</p>
									<p class="service-hour">
										<span>JAGA KESEHATAN</span>
										<strong>"UNTUK MASADEPAN YANG CERAH</strong>
									</p>
								</div>
							</div>
						</div>
					</div>
					<div class="tab-content" data-tab-content="tab6">
						<div class="container">
							<div class="row">
								<div class="col-md-6">
									<img src="images/buangsampah.jpg" class="img-responsive" alt="Image">
								</div>
								<div class="col-md-6">
									<span class="super-heading-sm">KEENAM</span>
									<h3 class="heading">JAGA LINGKUNGANMU</h3>
									<p>Lingkungan juga sangat mempengaruhi kesehatanmu, jika anda hidup di lingkungan yang tidak sehat maka anda juga akan terkena virus dan penyakit, oleh karena itu jaga lingkunganmu, tapi bagaimana caranya? itu mudah saja, anda dapat melakukan prinsip 4R,Reboisasi,Kuburlah sampah dan jangan membakarnya, dan tentunya buanglah sampah pada tempatnya.</p>
									<p>Jadi, jagalah lingkunganmu tuk hidup sehat selain itu juga dapat memperindah sekitarmu,karena tidak ada sampah dan tetap bersih.</p>
									<p class="service-hour">
										<span>JAGA KESEHATAN</span>
										<strong>"UNTUK MASADEPAN YANG CERAH"</strong>
									</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div id="testimonial" style="margin-top: 400px;">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="section-title text-center">
						<h2>YOU HAVE COMMENTS? SUGGESTION? THEN SEND TO US!</h2>
						<p>(untuk saran dan komentar anda harus login terlebih dahulu dan kirim di contact)</p>
						<p>"Update Setiap Minggunya"</p>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-4">
					<div class="testimony">
						<blockquote>
							&ldquo;Terimakasih,Cukup membantu untuk mengenal beberapa penyakit yang ada, dan terimakasih untuk cara hidup sehatnya&rdquo;
						</blockquote>
						<p class="author"><cite>Silvester Erlangga Setya P</cite></p>
					</div>
				</div>
				<div class="col-md-4">
					<div class="testimony">
						<blockquote>
							&ldquo;Menunggu Saran dan Komentar&rdquo;
						</blockquote>
						<p class="author"><cite>...</cite></p>
					</div>
				</div>
				<div class="col-md-4">
					<div class="testimony">
						<blockquote>
							&ldquo;Menunggu Saran dan Komentar&rdquo;
						</blockquote>
						<p class="author"><cite>...</cite></p>
					</div>
				</div>
			</div>
		</div>
	</div>

	<footer id="footer" class="fh5co-bg-color">
		<div class="container">
			<div class="row">
				<div class="col-md-3">
					<div class="copyright">
						<p> 2018 Akbar's medical care. <br> Banjarnegara. <br>
						Designed by <a href="https://www.facebook.com/dhany.ramadhani.52" target="_blank">Akbar Ramadhani</a> <br> 
						Instagram @Akbrrd_ <br></a></small></p>
					</div>
				</div>

	</div>
	</div>
	<script src="js/jquery-2.1.4.min.js"></script>
	<script src="js/hoverIntent.js"></script>
	<script src="js/superfish.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/jquery.countTo.js"></script>
	<script src="js/jquery.stellar.min.js"></script>
	<script src="js/bootstrap-datepicker.min.js"></script>
	<script src="js/classie.js"></script>
	<script src="js/selectFx.js"></script>
	<script src="js/jquery.flexslider-min.js"></script>
	<script src="js/custom.js"></script>

</body>
</html>