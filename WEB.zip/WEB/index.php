<!DOCTYPE >
<html>
<head>
<title>A'medical health care </title>

<link rel="stylesheet" type="text/css" href="styles.css" />

</head>

<body>

<div id="carbonForm">
	<h1>Sign up</h1>

    <form action="proses_register.php" method="post" id="signupForm">

    <div class="fieldContainer">

        <div class="formRow">
            <div class="label">
                <label for="nama">nama:</label>
            </div>
            
            <div class="field">
                <input type="text" name="name" id="name" required autofocus autocomplete="off">
            </div>
        </div>
        
        <div class="formRow">
            <div class="label">
                <label for="email">email:</label>
            </div>
            
            <div class="field">
                <input type="text" name="email" id="email" required autofocus autocomplete="off">
            </div>
        </div>
        
        <div class="formRow">
            <div class="label">
                <label for="pass">Password:</label>
            </div>
            
            <div class="field">
                <input type="password" name="password" id="pass" required autofocus autocomplete="off">
            </div>
        </div>
        
        
    </div> <!-- Closing fieldContainer -->
    
    <div class="signupButton">
        <input type="submit" name="submit" id="submit" value="Signup" >
    </div>
    
    </form>
        
</div>

</body>
</html>
