<?php  
	require 'koneksi.php';
	if (isset($_POST["submit"])) {
		$nama	=$_POST["name"];
		$email	=$_POST["email"];		
		$Pass	=$_POST["password"];

		$insert	="INSERT INTO register values ('','$nama','$email','$Pass')";
		$querry	=mysqli_query($koneksi,$insert);
		if (mysqli_affected_rows($koneksi)) {
		 	echo "
		 		<script>
		 			alert('SELAMAT DATANG');
		 			document.location.href='Utama.php';
		 		</script>
		 	";
		 	// header("LOCATION:Utama.php");
		 }else{
		 	echo "
		 		<script>
		 			alert('GAGAL REGISTRASI');
		 			document.location.href='index.php';
		 		</script>
		 	";
		 	// header("LOCATION:index.php");
		 }
	}
?>