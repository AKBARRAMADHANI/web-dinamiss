<?php 
include 'koneksi.php';
$nama = $_POST['nama'];
$email = $_POST['email'];
$sarandankomentar = $_POST['sarandankomentar'];

mysql_query("INSERT INTO sarandankomentar VALUES('','$nama','$email','$sarandankomentar')");

header("location:index.php?pesan=input");
?>